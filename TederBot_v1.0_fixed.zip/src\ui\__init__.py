"""
Rich |t� 0 �� ��0� UI ��

�� l1 ��:
- components.py: ���  �\ UI ����
- dashboard.py:  ��� tD�  pt0 ��0
- monitor.py: �� ��0� Tx t��

�� �:
    from src.ui.monitor import TradingMonitor, MonitoringConfig
    
    # ��0 �1
    config = MonitoringConfig(refresh_rate=1.0)
    monitor = TradingMonitor(config)
    
    # pt0 \1 $
    monitor.set_data_callback(strategy.execute_cycle)
    
    # ��0� ܑ
    monitor.start_monitoring()
"""

from .components import UIComponents, ColorScheme
from .dashboard import TradingDashboard, DashboardDataFormatter
from .monitor import (
    TradingMonitor, 
    MonitoringConfig, 
    MonitoringDataManager,
    create_monitor,
    run_monitor_with_strategy
)

__all__ = [
    'UIComponents',
    'ColorScheme', 
    'TradingDashboard',
    'DashboardDataFormatter',
    'TradingMonitor',
    'MonitoringConfig',
    'MonitoringDataManager',
    'create_monitor',
    'run_monitor_with_strategy'
]